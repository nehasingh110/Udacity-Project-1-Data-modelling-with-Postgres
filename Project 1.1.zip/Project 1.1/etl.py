import os
import glob
import psycopg2
import pandas as pd
from sql_queries import *
from array import *
import numpy as np

"""Method to perform ETL on the first dataset, song_data, to create the songs 
and artists dimensional tables."""
def process_song_file(cur, filepath):
    
    # Reading the song file and storing it in DataFrame called df
    df = pd.read_json(filepath,lines = True)

    # Extracting Data for Songs Table
    
    # Selected columns for song ID, title, artist ID, year, and duration
    df_songs = df[['song_id', 'title','artist_id','year','duration']]
    # Dropped records with null values
    df_songs = df_songs.dropna()
    # Dropped duplicates based on column song_id
    df_songs = df_songs.drop_duplicates(subset='song_id', keep="last", inplace=False)
    # Used df_songs.values to select just the values from the dataframe df_songs to save in array called `arr_songs`
    arr_songs = df_songs.values
    # Converted the array to a list called song_data
    song_data = np.array(arr_songs).tolist()
    
    """inserting all the elements(which is equivalent of each row in a db table)from song_data list to songs table
    by implementing the song_table_insert query in sql_queries.py"""
    for i in range(len(song_data)):
        cur.execute(song_table_insert, song_data[i])
    
    
    # Extracting Data for Artists Table
    
    # Selecting columns for artist ID, name, location, latitude, and longitude
    df_artists = df[['artist_id', 'artist_name','artist_location','artist_latitude','artist_longitude']]
    # Dropped records with null values
    df_artists = df_artists.dropna()
    # Dropped duplicates based on column artist_id
    df_artists = df_artists.drop_duplicates(subset='artist_id', keep="last", inplace=False)
    # Used df_artists.values to select just the values from the dataframe df_artists
    arr_artists = df_artists.values
    # Converted the array to a list called artist_data
    artist_data = np.array(arr_artists).tolist()
    
    """inserting artist records by implementing the artist_table_insert query in sql_queries.py.
        Also checking the length of artist_data list in case the list is empty the insert query shouldn't be 
        executed otherwise we'll get an out of index error"""
    if (len(artist_data) > 0):
        for i in range(len(artist_data)):
            cur.execute(artist_table_insert, artist_data[i])
            
            
            
"""Method to perform ETL on the second dataset, log_data, to create the time and users dimensional tables, 
as well as the songplays fact table."""            
def process_log_file(cur, filepath):
   
    # Reading the log file, storing in a DataFrame called df and dropping records with null values.
    df = pd.read_json(filepath,lines = True)
    df = df.dropna()
    
    # filterered DataFrame by NextSong action
    df = df[(df.page == 'NextSong')]

    # Converted the ts timestamp column to datetime
    t = pd.to_datetime(df['ts'], unit='ms')
    
    """Extracted the timestamp, hour, day, week of year, month, year, and weekday from the ts column and stored
    in a list time_data containing these values in order using pandas' dt attribute to access datetimelike properties."""
    time_data = [t.dt.time,t.dt.hour,t.dt.day,t.dt.week,t.dt.month,t.dt.year,t.dt.weekday]
    # Specified labels for these columns and set to column_labels
    column_labels = ['start_time', 'hour', 'day', 'week', 'month', 'year', 'weekday']
    """Created a dataframe, time_df, containing the time data for this file by combining column_labels and time_data
    into a dictionary and converted this into a dataframe."""
    t_dict = dict(zip(column_labels,time_data))
    time_df = pd.DataFrame.from_dict(t_dict)
    # Dropped records with null values
    time_df = time_df.dropna()
    # Dropped duplciates on start_time since it's the primary key and can't contain multiple rows with same value
    time_df = time_df.drop_duplicates(subset='start_time', keep="last", inplace=False)
    
    """Implemented the time_table_insert query in sql_queries.py to insert records for the timestamps in this 
    log file into the time table."""
    for i, row in time_df.iterrows():
        cur.execute(time_table_insert, list(row))

    # Extracting Data for Users Table
    
    # Selected columns for user ID, first name, last name, gender and level and set to user_df
    user_df = df[['userId', 'firstName', 'lastName', 'gender', 'level']]
    # Dropped records with null values using df.dropna()
    user_df = user_df.dropna()

    """inserted user records by implementing the user_table_insert query in sql_queries.py to insert records
    for the users in this log file into the users table."""
    for i, row in user_df.iterrows():
            cur.execute(user_table_insert, row)

    # Extracting Data for Songplays Table
    for index, row in df.iterrows():
        
        """Implemented the song_select query in sql_queries.py to find the song ID and artist ID from
        song and artist tables based on the title, artist name, and duration of a song """
        cur.execute(song_select, (row.song, row.artist, row.length))
        # Stored the results from song_select query in results variable.
        results = cur.fetchone()
        
        if results:
            songid, artistid = results
        else:
            songid, artistid = None, None

        # Converted the ts timestamp column to datetime
        t1 = pd.to_datetime(row.ts, unit='ms')
        
        
        # Inserting Records into Songplays Table
        
        # Selected the datetime, user ID, level, song ID, artist ID, session ID, location, and user agent and set to songplay_data
        songplay_data = (t1, row.userId, row.level, songid, artistid, row.sessionId, row.location, row.userAgent)
        """Inserted Records into Songplays Table by Implementing the songplay_table_insert query
        and passing data values through songplay_data"""
        cur.execute(songplay_table_insert, songplay_data)


"""Method to generate list of all song or log json files and call other methods to perform ETL and load db tables"""
def process_data(cur, conn, filepath, func):
    # method to get all files matching .json extension from directory
    all_files = []
    for root, dirs, files in os.walk(filepath):
        files = glob.glob(os.path.join(root,'*.json'))
        for f in files :
            all_files.append(os.path.abspath(f))

    # get total number of files found
    num_files = len(all_files)
    print('{} files found in {}'.format(num_files, filepath))

    # iterate over files and process
    for i, datafile in enumerate(all_files, 1):
        func(cur, datafile)
        conn.commit()
        print('{}/{} files processed.'.format(i, num_files))
        print(datafile)


def main():
    # Created connection to the sparkifydb database and a cursor to it
    conn = psycopg2.connect("host=127.0.0.1 dbname=sparkifydb user=student password=student")
    cur = conn.cursor()

    # calling process_data method for song data 
    process_data(cur, conn, filepath='data/song_data', func=process_song_file)
    # calling process_data method for log data 
    process_data(cur, conn, filepath='data/log_data', func=process_log_file)

    # Closing Connection to Sparkify Database
    conn.close()


if __name__ == "__main__":
    #calling main method
    main()